=== Tako Data Visualization ===
Contributors: jintako
Tags: data visualization
Requires at least: 4.7
Tested up to: 6.4.3
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html


The Tako Data Visualization plugin allows users to embed responsive data-driven
visualizations from https://www.trytako.com.

* Frequently Asked Questions

Q: Do I need to register on trytako.com to use this plugin?

A: Registration is not necessary, but enterprise users will need to login to
   access themes and other data specific to the enterprise account.

For support or additional questions, please reach out to hello@trytako.com.